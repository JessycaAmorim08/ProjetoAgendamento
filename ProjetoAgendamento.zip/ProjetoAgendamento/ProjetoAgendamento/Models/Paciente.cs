﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ProjetoAgendamento.Models
{
  public class Paciente
  {
    public int Id { get; set; }

    [Required(ErrorMessage = "Insira o nome válido!")]
    [StringLength(100)]
    [Display(Name = "Nome")]
    public string Nome { get; set; }
    [Required]
    [StringLength(12)]
    [Display(Name = "Telefone")]
    public string Telefone { get; set; }
    [Required(ErrorMessage = "Insira só números!")]
    [StringLength(11)]
    [Display(Name = "CPF")]
    public string CPF { get; set; }
    [Required]
    [Display(Name = "Data de Nascimento")]
    public DateTime DataNascimento { get; set; }
  }
}
