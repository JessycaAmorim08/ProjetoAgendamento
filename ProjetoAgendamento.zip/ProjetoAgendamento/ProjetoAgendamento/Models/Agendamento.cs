﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetoAgendamento.Models
{
  public class Agendamento
  {
    public int id { get; set; }
    public int idPaciente { get; set; }
    public Paciente paciente { get; set; }
    public int idAgenda { get; set; }
    public Agenda agenda { get; set; }

  }
}
