﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetoAgendamento.Models
{
  public class Sala
  {
    public int id { get; set; }
    public string Nome { get; set; }
    public string Especialidade { get; set; }
  }
}
