﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetoAgendamento.Models
{
  public class Agenda
  {
    public DateTime DataHora { get; set; }
    public Sala sala { get; set; }
    public int IdSala { get; set; }
    public string Descricao { get; set; }
    public int id { get; set; }
  }
}
