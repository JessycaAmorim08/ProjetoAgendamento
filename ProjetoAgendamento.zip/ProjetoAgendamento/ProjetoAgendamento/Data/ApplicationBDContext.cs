﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ProjetoAgendamento.Models;

namespace ProjetoAgendamento.Data
{
    public class ApplicationBDContext : DbContext
    {
        public ApplicationBDContext (DbContextOptions<ApplicationBDContext> options)
            : base(options)
        {
        }

        public DbSet<ProjetoAgendamento.Models.Sala> Sala { get; set; }

        public DbSet<ProjetoAgendamento.Models.Paciente> Paciente { get; set; }

        public DbSet<ProjetoAgendamento.Models.Agenda> Agenda { get; set; }

        public DbSet<ProjetoAgendamento.Models.Agendamento> Agendamento { get; set; }
    }
}
