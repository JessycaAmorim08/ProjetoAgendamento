CREATE TABLE Paciente (
   id INT IDENTITY(1,1) not null
  ,Nome VARCHAR(100) not null
  ,Telefone VARCHAR(12) not null
  ,CPF VARCHAR(11) not null
  ,DataNascimento DATATIME not null
  ,CONSTRAINT pk_Paciente PRIMARY KEY (id)
)