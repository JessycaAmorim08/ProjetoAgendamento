CREATE TABLE Agenda (
   id INT IDENTITY(1,1) not null
  ,Data DATE not null
  ,Hora TIME not null
  ,idSala INT not null
  ,CONSTRAINT pk_Agenda PRIMARY KEY (id)
  ,CONSTRAINT fk_Agenda_idSala foreign key (idSala) references dbo.Sala(Id)
)