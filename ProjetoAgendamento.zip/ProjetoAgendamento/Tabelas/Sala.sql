CREATE TABLE Sala (
   id INT IDENTITY(1,1) not null
  ,Nome VARCHAR(20) not null
  ,Especialidade VARCHAR(20) not null
  ,CONSTRAINT pk_Sala PRIMARY KEY (id)
)