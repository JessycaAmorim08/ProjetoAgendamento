CREATE TABLE Agendamento (
   id INT IDENTITY(1,1) not null
  ,idPaciente INT not null
  ,idAgenda INT not null
  ,CONSTRAINT pk_Agendamento PRIMARY KEY (id)
  ,CONSTRAINT fk_Agendamento_IdPaciente foreign key (IdPaciente) references dbo.Paciente(Id)
  ,CONSTRAINT fk_Agendamento_idAgenda foreign key (idAgenda) references dbo.Agenda(Id)
)